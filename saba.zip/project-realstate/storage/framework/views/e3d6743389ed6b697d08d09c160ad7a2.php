<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ثبت کار جدید</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/Style.css')); ?>">
</head>
<body>

    <div class="bg-wrapper"></div>

    <div class="container">

        <header class="header">
            <div class="header-left">
                <div class="logo-box">حس</div>
                <div>
                    <h1>ثبت کار جدید</h1>
                    <div class="subtitle">افزودن کار به لیست</div>
                </div>
            </div>
            <div class="header-right">
                <div class="user-badge">
                    <div class="avatar"><?php echo e(substr(auth()->user()->name, 0, 1)); ?></div>
                    <div class="user-meta">
                        <div class="name"><?php echo e(auth()->user()->name); ?></div>
                        <div class="role">مدیر ارشد</div>
                    </div>
                </div>
                <form method="POST" action="<?php echo e(route('logout')); ?>" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn-logout">خروج</button>
                </form>
            </div>
        </header>

        <a href="<?php echo e(route('master.todos.index')); ?>" class="back-link">بازگشت به لیست کارها</a>

        <?php if($errors->any()): ?>
            <div style="background:rgba(239,68,68,0.06); border:1px solid rgba(239,68,68,0.12); border-radius:14px; padding:14px 20px; margin-bottom:20px; color:#dc2626; font-size:15px;">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($error); ?><br>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>

        <div class="form-card">
            <form method="POST" action="<?php echo e(route('master.todos.store')); ?>">
                <?php echo csrf_field(); ?>

                <div class="form-group">
                    <label for="title">عنوان کار <span style="color:#dc2626;">*</span></label>
                    <input type="text" id="title" name="title" value="<?php echo e(old('title')); ?>" placeholder="عنوان کار را وارد کنید" required>
                    <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="description">توضیحات (اختیاری)</label>
                    <textarea id="description" name="description" rows="3" style="width:100%; padding:14px 18px; background:#f8fafc; border:2px solid #e5e7eb; border-radius:14px; color:#1a1a2e; font-size:15px; outline:none; transition:all 0.3s; resize:vertical; font-family:inherit;"><?php echo e(old('description')); ?></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="due_date">تاریخ سررسید (اختیاری)</label>
                    <input type="text" 
                           id="due_date" 
                           name="due_date" 
                           value="<?php echo e(old('due_date')); ?>"
                           placeholder="مثال: 1404/06/25"
                           dir="ltr"
                           style="width:100%; padding:14px 18px; background:#f8fafc; border:2px solid #e5e7eb; border-radius:14px; color:#1a1a2e; font-size:15px; transition:all 0.3s; outline:none; direction:ltr; text-align:center; font-family:inherit;">
                    <div class="help-text">اختیاری - هر تاریخی که دوست دارید وارد کنید</div>
                    <?php $__errorArgs = ['due_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="error"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-actions">
                    <a href="<?php echo e(route('master.todos.index')); ?>" class="btn-cancel">بازگشت</a>
                    <button type="submit" class="btn-submit">ثبت کار</button>
                </div>
            </form>
        </div>

    </div>

</body>
</html><?php /**PATH E:\GitHub\realstate\project-realstate\resources\views/master/todos/create.blade.php ENDPATH**/ ?>