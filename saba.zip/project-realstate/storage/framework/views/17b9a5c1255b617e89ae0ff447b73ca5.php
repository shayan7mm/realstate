<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>داشبورد مدیریت</title>
    <link rel="stylesheet" href="<?php echo e(asset('css/Style.css')); ?>">
    <style>
        .section-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 16px;
            margin-bottom: 30px;
        }
        .section-grid .btn-section {
            padding: 18px 20px;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 600;
            font-size: 15px;
            transition: all 0.3s ease;
            text-align: center;
            color: #fff;
            cursor: pointer;
            border: none;
            box-shadow: 0 4px 16px rgba(0, 0, 0, 0.08);
        }
        .section-grid .btn-section:hover {
            transform: translateY(-4px);
            box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
        }
        .section-grid .btn-section .icon {
            display: block;
            font-size: 28px;
            margin-bottom: 6px;
        }
        .section-grid .btn-section.cars { background: linear-gradient(135deg, #3b82f6, #2563eb); }
        .section-grid .btn-section.houses { background: linear-gradient(135deg, #8b5cf6, #7c3aed); }
        .section-grid .btn-section.persons { background: linear-gradient(135deg, #10b981, #059669); }
        .section-grid .btn-section.organizations { background: linear-gradient(135deg, #f59e0b, #d97706); }
        .section-grid .btn-section.expenses { background: linear-gradient(135deg, #ef4444, #dc2626); }
        .section-grid .btn-section.users { background: linear-gradient(135deg, #06b6d4, #0891b2); }
        .section-grid .btn-section.permissions { background: linear-gradient(135deg, #ec4899, #db2777); }
        .section-grid .btn-section.reports { background: linear-gradient(135deg, #6366f1, #4f46e5); }

        .accountant-card {
            background: #ffffff;
            border-radius: 16px;
            padding: 18px 22px;
            border: 1px solid rgba(0, 0, 0, 0.04);
            box-shadow: 0 2px 12px rgba(0, 0, 0, 0.03);
            transition: all 0.3s ease;
        }
        .accountant-card:hover {
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.06);
        }
        .accountant-card .name {
            font-size: 16px;
            font-weight: 600;
            color: #1a1a2e;
        }
        .accountant-card .info {
            font-size: 13px;
            color: #6b7280;
        }
        .accountant-card .status-badge {
            font-size: 12px;
            padding: 2px 12px;
            border-radius: 20px;
        }
        .accountant-card .status-badge.active {
            background: rgba(16, 185, 129, 0.10);
            color: #059669;
        }
        .accountant-card .status-badge.inactive {
            background: rgba(239, 68, 68, 0.06);
            color: #dc2626;
        }
        .accountant-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 16px;
            margin-top: 16px;
        }
        .section-title {
            font-size: 18px;
            font-weight: 700;
            color: #1a1a2e;
            margin-bottom: 12px;
        }
        .section-title .badge {
            font-size: 13px;
            font-weight: 400;
            color: #6b7280;
        }
    </style>
</head>
<body>

    <div class="bg-wrapper"></div>

    <div class="container">

        <!-- ===== HEADER ===== -->
        <header class="header">
            <div class="header-left">
                <div class="logo-box">حس</div>
                <div>
                    <h1>سیستم حسابداری</h1>
                    <div class="subtitle">پنل مدیریت - مستر</div>
                </div>
            </div>
            <div class="header-right">
                <div class="user-badge">
                    <div class="avatar"><?php echo e(substr(auth()->user()->name, 0, 1)); ?></div>
                    <div class="user-meta">
                        <div class="name"><?php echo e(auth()->user()->name); ?></div>
                        <div class="role">مدیر ارشد</div>
                    </div>
                </div>
                <a href="<?php echo e(route('profile.edit')); ?>" style="color:#6b7280; text-decoration:none; font-size:14px;">پروفایل</a>
                <form method="POST" action="<?php echo e(route('logout')); ?>" style="display:inline;">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn-logout">خروج از حساب</button>
                </form>
            </div>
        </header>

        <!-- ===== STATS ===== -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-number"><?php echo e($totalAccountants); ?></div>
                <div class="stat-label">کل حسابداران</div>
               
            </div>

            <div class="stat-card">
                <div class="stat-number"><?php echo e($activeAccountants); ?></div>
                <div class="stat-label">حسابداران فعال</div>
                
            </div>

            <div class="stat-card">
                <div class="stat-number"><?php echo e($inactiveAccountants); ?></div>
                <div class="stat-label">حسابداران غیرفعال</div>
               
            </div>

            <div class="stat-card">
                <div class="stat-number"><?php echo e($totalAccountants); ?></div>
                <div class="stat-label">مدیریت کاربران</div>
                <a href="<?php echo e(route('master.users')); ?>" style="color:#4f46e5; text-decoration:none; font-size:14px; display:inline-block; margin-top:8px; font-weight:500;">
                    مشاهده همه →
                </a>
            </div>
        </div>

        <!-- ===== SECTION BUTTONS (رنگی رنگی) ===== -->
        <div class="section-grid">
            <a href="<?php echo e(route('cars.index')); ?>" class="btn-section cars">
                <span class="icon"></span>
                ماشین‌ها
            </a>
            <a href="<?php echo e(route('houses.index')); ?>" class="btn-section houses">
                <span class="icon"></span>
                منازل
            </a>
            <a href="<?php echo e(route('persons.index')); ?>" class="btn-section persons">
                <span class="icon"></span>
                اشخاص
            </a>
            <a href="<?php echo e(route('organizations.index')); ?>" class="btn-section organizations">
                <span class="icon"></span>
                ارگان‌ها
            </a>
            <a href="<?php echo e(route('expenses.index')); ?>" class="btn-section expenses">
                <span class="icon"></span>
                هزینه‌ها
            </a>
            <a href="<?php echo e(route('master.users')); ?>" class="btn-section users">
                <span class="icon"></span>
                کاربران
            </a>
            <a href="<?php echo e(route('master.todos.index')); ?>" class="btn-section" style="background: linear-gradient(135deg, #f472b6, #ec4899);">
                کار روزانه
            </a>
        </div>

        <!-- ===== RECENT ACCOUNTANTS ===== -->
        <div class="table-wrapper">
            <div class="table-header">
                <h3>📋 آخرین حسابداران ثبت‌نام شده</h3>
                <div class="count"><?php echo e($recentUsers->count()); ?> نفر</div>
            </div>

            <div class="table-wrap">
                <table>
                    <thead>
                        <tr>
                            <th>ردیف</th>
                            <th>نام</th>
                            <th>ایمیل</th>
                            <th>موبایل</th>
                            <th>وضعیت</th>
                            <th>تاریخ ثبت</th>
                            <th>عملیات</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $recentUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($user->name); ?></td>
                                <td><?php echo e($user->email); ?></td>
                                <td dir="ltr"><?php echo e($user->phone); ?></td>
                                <td>
                                    <span class="status-badge <?php echo e($user->is_active ? 'active' : 'inactive'); ?>">
                                        <?php echo e($user->is_active ? 'فعال' : 'غیرفعال'); ?>

                                    </span>
                                </td>
                                <td><?php echo e(verta($user->created_at)->format('%d %B %Y')); ?></td>
                                <td>
                                    <div class="action-btns">
                                        <a href="<?php echo e(route('master.users.edit', $user)); ?>" class="edit">ویرایش</a>
                                        <a href="<?php echo e(route('permissions.index', $user)); ?>" class="edit" style="background:rgba(236,72,153,0.08); color:#ec4899;">دسترسی</a>
                                        <form action="<?php echo e(route('master.users.destroy', $user)); ?>" method="POST" style="display:inline;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="delete" onclick="return confirm('آیا از حذف این کاربر مطمئن هستید؟')">حذف</button>
                                        </form>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="7">
                                    <div class="empty-state">
                                        <p>هیچ حسابداری ثبت نشده است</p>
                                        <a href="<?php echo e(route('master.users.create')); ?>">ثبت اولین حسابدار</a>
                                    </div>
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <?php if($recentUsers->count() > 0): ?>
                <a href="<?php echo e(route('master.users')); ?>" class="view-all">مشاهده تمام حسابداران →</a>
            <?php endif; ?>
        </div>

    </div>

</body>
</html><?php /**PATH E:\GitHub\realstate\project-realstate\resources\views/dashboard/master.blade.php ENDPATH**/ ?>